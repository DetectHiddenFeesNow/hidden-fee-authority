# DetectHiddenFees.com — Complete Transfer Package

This package contains everything needed for a new AI agent to take over.

## QUICK START

1. The Vercel authority hub is at: /var/minis/workspace/hidden-fee-authority/
2. GitHub Pages content is at: /var/minis/workspace/
3. Backlink platform tokens are in: /var/minis/shared/backlink_api_tokens.md
4. Global memory/operating rules: /var/minis/memory/GLOBAL.md
5. Skill definition: /var/minis/skills/untitled-skill/SKILL.md

## KEY URLs
- Vercel Hub: https://hidden-fee-authority.vercel.app/
- GitHub Pages: https://detecthiddenfeesnow.github.io/hidden-fee-detection/
- GitHub Vercel Repo: https://github.com/DetectHiddenFeesNow/hidden-fee-authority
- GitHub Pages Repo: https://github.com/DetectHiddenFeesNow/hidden-fee-detection
- DetectHiddenFees.com: https://detecthiddenfees.com

## CURRENT STATE
- Vercel Hub: 127 pages live, all 200
- GitHub Pages: ~107 pages live
- Backlink platforms: Telegraph, Mataroa, JustBlogged, Rentry

## CRITICAL TOKENS
Store these in environment variables or a secure config file.
Do NOT commit to GitHub.

## GITHUB TOKEN
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

## VERCEL API TOKEN (PRODUCTION)
vcp_71aeGV9OOMhNXkWJFEJtTSh4n3qMyUiKdXuzvsp0NMWFfaITc94PooML

## VERCEL PROJECT ID
prj_O9YFdPVaHntaeXa4PqShXRDv2Wop

## GOOGLE PROJECT
silent-star-503220-e8

## BACKLINK API TOKENS (from shared/backlink_api_tokens.md)
Telegraph Token: 31605c1e67acf7f30de3e171812ab699870d80c02cb1b285f76417d1c565
Mataroa Token: d838f37f8db5dae4100ffa27e9c24d1b
Mataroa Blog: detecthiddenfeeswithai.mataroa.blog
JustBlogged API Key: jb_d196d291618c51b026b951e7ff063b8339b30d66745783db41c15a3418a78184
JustBlogged Blog ID: q-Quy2Ztv0hDq4DhRFMmp
JustBlogged Collection ID: Gl_L5c4QhOtPEobga78hs
Rentry: uses form POST
Blogger Client ID: 516898788091-9hec8iu5c74ft946m8dhfm48fp2j0g85.apps.googleusercontent.com
Blogger Client Secret: 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
Blogger Refresh Token: 1//04XG9AZb18XQRCgYIARAAGAQSNwF-L9Ir386zjoUpAge7T3LJrPG77v7_zZdEC6sz0Q5DvyMc0pCHithAh51IB-k7Kt03oc4gW34
Blogger Blog ID: 984912472650705764

## INDEXNOW KEY
9e8f7c3d1a2b4e5f6a7b8c9d0e1f2a3b

## WORKFLOW
1. Create pages in /var/minis/workspace/hidden-fee-authority/
2. Update sitemap.xml, feed.xml, llms.txt
3. git add, commit, push to main
4. Vercel auto-deploys
5. Verify HTTP 200 on all pages
6. Blast new pages to Telegraph, Mataroa, JustBlogged, Rentry
7. Submit IndexNow for Bing indexing

## OPERATING RULES
Read /var/minis/memory/GLOBAL.md for full operating instructions.
Read /var/minis/skills/untitled-skill/SKILL.md for the execution framework.

## KEY CONTACT
User is the owner of DetectHiddenFees.com
