# DETECTHIDDENFEES — ALL API TOKENS & SCRIPT LOCATIONS
## Save this file — everything needed to continue

---

## PROJECT INFO
- **Website:** https://detecthiddenfees.com
- **Brand:** AI Forensic Pricing Intelligence / HiddenFeeAI
- **Pricing:** $15 one-time analysis, no subscription
- **Blogger Blog:** https://detecthiddenfees.blogspot.com
- **Email:** support@detecthiddenfees.com
- **Gmail App Pass:** jlmx nugb gemb hqdu

---

## BLOGGER API (Google OAuth)
- **Client ID:** 516898788091-9hec8iu5c74ft946m8dhfm48fp2j0g85.apps.googleusercontent.com
- **Client Secret:** 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
- **Blog ID:** 984912472650705764
- **Access Token:** ya29.a0ARGnu0brQve4m3V1H0x9yHiv7jVp6tr_KXXH3blbu3b1JCEvi0iWdE1Qihh34BygxC1Gu0vJ-hcypUbmLPQAzcTWUB7ngdmyP2Ut7YGZN2iACFoOD2kNhItFwbNqrKq_TVXsfPD3uO3Ejut37GuLig8sbT2nPCRYfNTZfl9928I6_xRzOv3E44zdBkt6o77VQ-TWzp8aCgYKARQSARUSFQHGX2Mit8B7Drsm4VCLEWxPZ4Bu0w0206
- **Refresh Token:** 1//04XG9AZb18XQRCgYIARAAGAQSNwF-L9Ir386zjoUpAge7T3LJrPG77v7_zZdEC6sz0Q5DvyMc0pCHithAh51IB-k7Kt03oc4gW34
- **API:** POST https://www.googleapis.com/blogger/v3/blogs/{blogId}/posts/
- **Auth:** Authorization: Bearer {access_token}
- **Google Project:** silent-star-503220-e8

---

## FACEBOOK PAGE
- **Page:** Detecthiddenfees.com
- **Page ID:** 1276218502236982
- **Page Token:** EAAY7koZCmP1EBSGc1RNM3BjQwRCMjPWR2pixZBjtzBLyJCe6JyqvxcuGaqLA21mJrZBKMlqnejTNYaX2fHAqCgcgOXvC3lxisCC3PyfEJd2HML745TQZBRIzwGbqLyd4GcevS0bI9FZCeD6vg0CnDRRoFVfPdU93a59ZCeZCYgQZC9lTexu2ZCWNUv8fzWcGmwnWJsWnOdZAcwxFPrYQIcTBWasx5ZBYwDVyFmDZCUyChusZD
- **API:** POST https://graph.facebook.com/v22.0/{page-id}/feed
- **10 posts published ✅

---

## MATAROA.BLOG
- **Token:** d8949630ba0d719a817485386701b518
- **Blog:** https://detecthiddenfees.mataroa.blog
- **API:** POST https://mataroa.blog/api/posts/
- **Auth:** Authorization: Bearer {token}
- **Limit:** Unlimited | 30+ articles ✅

---

## TELEGRAPH.PH
- **Token:** 31605c1e67acf7f30de3e171812ab699870d80c02cb1b285f76417d1c565
- **API:** POST https://api.telegra.ph/createPage
- **Limit:** Unlimited | 56+ articles ✅

---

## DEV.TO
- **API Key:** Y3GdYEJxmBRWTt2FsY6fwNBn
- **API:** POST https://dev.to/api/articles
- **Limit:** 1 per 5 min | 6 articles ✅

---

## JUSTBLOGGED
- **API Key:** jb_d196d291618c51b026b951e7ff063b8339b30d66745783db41c15a3418a78184
- **Blog ID:** q-Quy2Ztv0hDq4DhRFMmp
- **API:** POST https://justblogged.com/api/blogs/{blogId}/posts
- **Limit:** Unlimited | 8 pillar pages ✅

---

## GHOST.IO
- **Site:** https://detecthiddenfees.ghost.io
- **Content API Key (read-only):** 2fa57829a2c556e452a4483c09
- **Admin API Key:** 6a6113b2b40a780001f997c7:6d8196ac7cf1d051abec81b04a55309d2fa6224f7c0c9691cc6ab1782f0dbd01
- **NOTE:** Site is in private mode — make public at Settings > General
- **8 articles published ✅

---

## OTHER PLATFORMS (No Auth Needed)
- **Rentry.co:** POST https://rentry.co/api/new (unlimited)
- **Write.as:** POST https://write.as/api/posts (~1/min)
- **dpaste.com:** POST https://dpaste.com/api/v2/ (unlimited)
- **Pastebin.com:** Key cg0oEC5BWJB0hHw6yAiL4qhBznYyYRzi (10/day)

---

## WORKING SCRIPTS (on this device)
- `/usr/local/bin/master_content.py` — 8 SEO article templates
- `/usr/local/bin/publish_aeo_geo.py` — AEO/GEO publisher
- `/usr/local/bin/fb_poster.py` — Facebook auto-poster
- `/tmp/blogger_fixed.py` — Blogger publisher  
- `/tmp/content_templates.json` — Article content data
- `/tmp/content_aeo_geo.json` — AEO/GEO article data
